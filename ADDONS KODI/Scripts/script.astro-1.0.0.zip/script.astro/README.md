# script.astro
_A world of possibilities._

![](https://img.shields.io/badge/Python-3-blue)
![](https://img.shields.io/badge/Kodi-19-brightgreen)
![](https://img.shields.io/badge/Kodi-20-%238C25A5)
### Astro is a script to keep your favorite sections of your favorite add-ons in only one place.
### Morever, Astro allows to share your config and save it in the cloud!
### So the changes made by the admins, will be automatically updated on your device